import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
// Verify the authored directory can be loaded as plain JS after its export-only TS syntax.
const data=readFileSync(new URL('../lib/resources.ts',import.meta.url),'utf8');
const {resources}=await import('data:text/javascript,'+encodeURIComponent(data));
test('every resource has a unique id and official HTTPS source',()=>{assert.equal(new Set(resources.map(x=>x.id)).size,resources.length);for(const r of resources){assert.ok(r.name&&r.requirements&&r.hours);assert.equal(new URL(r.source).protocol,'https:');}});
test('physical map entries include usable Raleigh addresses',()=>{const physical=resources.filter(x=>['Groceries','Prepared meals'].includes(x.type));assert.equal(physical.length,4);for(const r of physical) assert.match(r.address,/Raleigh, NC \d{5}/);});
const route=readFileSync(new URL('../app/api/helper/route.ts',import.meta.url),'utf8');
// Node's built-in TypeScript stripping makes the route testable without the framework.
const executable=stripTypeScriptTypes(route.replace("import { resources } from '../../../lib/resources';",'const resources='+JSON.stringify(resources)+';'));
const {POST,GET}=await import('data:text/javascript,'+encodeURIComponent(executable));
test('missing key is explicit and does not pretend AI ran',async()=>{delete process.env.GEMMA_API_KEY;const r=await POST(new Request('https://app.test/api/helper',{method:'POST',body:JSON.stringify({message:'food'})}));assert.equal(r.status,503);assert.equal((await GET()).status,200);});
test('cross-origin requests are rejected',async()=>{const r=await POST(new Request('https://app.test/api/helper',{method:'POST',headers:{origin:'https://other.test'},body:'{}'}));assert.equal(r.status,403);});
test('oversized questions rejected before model call',async()=>{process.env.GEMMA_API_KEY='test-placeholder';const r=await POST(new Request('https://app.test/api/helper',{method:'POST',body:JSON.stringify({message:'x'.repeat(2001)})}));assert.equal(r.status,400);delete process.env.GEMMA_API_KEY;});
test('key stays server-side',()=>{assert.ok(!readFileSync(new URL('../app/page.tsx',import.meta.url),'utf8').includes('process.env.GEMMA_API_KEY'));assert.ok(route.includes("'x-goog-api-key'"));});
